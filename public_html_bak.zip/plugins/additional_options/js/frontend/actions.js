function remove_confirmation(message)
{
	opt = confirm(message);
	return opt;
}