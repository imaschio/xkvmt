<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */

function smarty_block_php($params, $content, &$smarty)
{
	return '';
}
