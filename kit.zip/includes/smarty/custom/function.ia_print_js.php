<?php

function smarty_function_ia_print_js($params, &$smarty)
{
	$smarty->smarty->add_js($params);
}
