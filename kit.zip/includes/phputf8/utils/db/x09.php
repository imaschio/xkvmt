<?php
$UTF8_TO_ASCII[0x09] = array(

);
