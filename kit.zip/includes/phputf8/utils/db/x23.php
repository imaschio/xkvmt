<?php
$UTF8_TO_ASCII[0x23] = array(

);
